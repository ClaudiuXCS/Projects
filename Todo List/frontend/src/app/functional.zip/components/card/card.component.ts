import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ITask } from 'src/app/models/itask';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent {

editOn: boolean = false;

@Input() item!: ITask;
@Output() editEvent = new EventEmitter<string>();
@Output() deleteEvent = new EventEmitter<number>();

showInput() {
  this.editOn = !this.editOn;
}

editItem(value: string) {
  this.editEvent.emit(this.item.id + "~" + value);
  this.editOn = !this.editOn;
}

deleteItem() {
  this.deleteEvent.emit(this.item.id);
}


}
