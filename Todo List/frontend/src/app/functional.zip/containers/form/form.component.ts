import { Component } from '@angular/core';
import { ITask } from 'src/app/models/itask';
import { TodoService } from 'src/app/services/todo.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent {

  todos!: ITask[];
  taskValue: string = '';
  editTaskValue: string = '';
  myTask: ITask = {description: '', id: 0};
  index: number = 25;

constructor(private todoService: TodoService) {}

ngOnInit() : void {
  this.editTaskValue = '';
  this.myTask.description = '';
  this.index+=1;
  this.todoService.readAll().subscribe({ next: (elements : ITask[]) => { this.todos = elements }, error: (err) => { alert("Error getting the list of tasks!")}});
}

createTask()
{
  this.myTask.description = this.taskValue;
  this.myTask.id = this.index;
  this.todoService.create(this.myTask).subscribe(
    { next: (response) => {
    this.ngOnInit();
    this.taskValue = '';
  }})
}

editTask(value: string)
{
  var fields = value.split('~');
  var id = Number(fields[0]);
  var description = fields[1];
  this.myTask.description = description;
  this.myTask.id = id;
  this.todoService.update(this.myTask).subscribe( 
    { next: (response) => {
    this.ngOnInit();
  }, error: (err) => { alert("Couldn't update the task.")} 
});
}

deleteTask(id : number)
{
  this.myTask.id = id;
  this.myTask.description = '25';
  this.todoService.delete(this.myTask).subscribe( 
    { next: (response) => {
    this.ngOnInit();
  }, error: (err) => { alert("Couldn't delete the task.")} 
});
}

myItem(editedItem: string)
{
  this.editTaskValue = editedItem;
  console.log(this.editTaskValue);
}
}
